﻿using System;
using System.Windows.Forms;

namespace ProjetoForns
{
    public partial class CadFuncionario : UserControl
    {
        private int id;
        public CadFuncionario(int id=0)
        {
            InitializeComponent();
            this.id = id;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.id == 0) { Cadastar(); } 
            else { Atualizar(); }
            
            Voltar();
        }

        private void BTM_0_Click(object sender, EventArgs e)
        {
            Voltar();
        }


        private void Cadastar() 
        { }
        private void Atualizar() 
        { }

        private void Voltar() 
        { ChamarSubTela(new MostarFuncionarios()); }



        private void ChamarSubTela(UserControl tela, string tipo = "")
        {
            Form1 formPai = this.ParentForm as Form1;

            if (formPai != null)
            {
                formPai.ChamarMineTela(tela, nivelAcesso: tipo);
            }
        }
    }
}
