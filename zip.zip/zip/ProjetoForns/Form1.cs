﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoForns
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            ChamarBase("Principal");
        }

       public static bool BostarLogoParaEstoque = false;

        private void ChamarBase(string nivelAcesso,UserControl controle=null)
        {
            if (nivelAcesso == "Principal")
            {
                ChamarTelaPrincipal();//ou MenuGerente ou TelaDeEscolha
                ChamarConsoleUser(new Cabesario(naoMostar2: "VoltarFuncionario"), "cabesario");
            }
            else 
            {
                ChamarTelaFuncionario(nivelAcesso, controle: controle);//ou Vendedor ou Estoque
                ChamarConsoleUser(new Cabesario(), "cabesario");
            }
                
        }


        private void ChamarTelaPrincipal() 
        {
            switch (Program.acessoRegular)//valor é definico no momento do login
            {
                case "gerente":
                    ValidadarPrimeiroAcesso();
                    ChamarConsoleUser(new MenuGerente(), "Menu");
                    break;
                case "vendedor":
                case "estoque":
                    ChamarConsoleUser(new TelaIntermediaria(), "full");
                    break;
            }
        }

        private UserControl ValidadarPrimeiroAcesso(UserControl cont=null) 
        {
            //Primeiro tela para o estoquista, Telalogo é impedor que seja chamada a tela TelaLogo
            if (BostarLogoParaEstoque == false) 
            {
                BostarLogoParaEstoque = true;
                
                if (cont != null)//Se for acesso ao estoque
                {cont = new TelaLogo();}

                else//Se for aceeo do gerente
                {ChamarConsoleUser(new TelaLogo(), "full");}       
            }
            return (cont != null) ? cont : null;
        }

        private void ChamarTelaFuncionario(string nivelAcesso, UserControl controle = null) 
        {
            //Acesso de estoque
            if (nivelAcesso == "estoque")
            {

                    //chamar as telas que estao no MenuEstoque
                    ChamarConsoleUser(ValidadarPrimeiroAcesso(controle), "full");
                       
                    //Chamar Menu Lateral do estoque
                    ChamarConsoleUser(new MenuEstoque(), "Menu");
               
            }
            else if (nivelAcesso == "venda")
            {
                //Acesso de venda
                ChamarConsoleUser(new TelaVenda(), "Full");
            }
        }
      

        private void ChamarConsoleUser(Control Tela,string tipo)
        {
            //add tela no form1
            Controls.Add(Tela);

            //posicionar o user control
            Tela.Dock = (tipo == "cabesario") ? DockStyle.Top : (tipo == "Menu") ? DockStyle.Left : DockStyle.Fill;
        }



        private void ExibirUserControl(UserControl novoControl, string nivelAcesso = "")
        {
      
            Controls.Clear();

            //Definir se o acesso e do gerente("Principal"), neste caso quando a variavel <nivelAcesso> for ""
            //Definir se o acesso e do funcionario("estoque" || "venda"), neste caso quando a variavel <nivelAcesso> for ""
            ChamarBase((nivelAcesso == "") ?"Principal": nivelAcesso,controle: novoControl);

            //se for nivel de acesso do gerente
            if (nivelAcesso == "") { ChamarConsoleUser(novoControl, "full"); }

            //Chamar para frente o usercontrol
            novoControl.BringToFront(); 
        }



        public void ChamarMineTela(UserControl Tela, string nivelAcesso)
        { 
               ExibirUserControl(Tela, nivelAcesso: nivelAcesso);
        }
    }
}
