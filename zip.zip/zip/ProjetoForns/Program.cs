﻿using System;
using System.Windows.Forms;

namespace ProjetoForns
{
    internal static class Program
    {


        public static bool voltar;
        public static int id_AtualSecao;
        public static string acessoRegular;


        static void RegistrarID_Secao(int id) 
        {
            id_AtualSecao= id;
        }



        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            do
            {
                TelaLogin login = new TelaLogin();
                voltar = false;

                if (login.ShowDialog() == DialogResult.OK) Application.Run(new Form1()); ;
            } 
            while (voltar == true);
        }

      
    }
}
