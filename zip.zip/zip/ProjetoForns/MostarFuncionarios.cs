﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoForns
{
    public partial class MostarFuncionarios : UserControl
    {
        public MostarFuncionarios()
        {
            InitializeComponent();
        }
        private int id=0;

        private void ChamarSubTela(UserControl tela, string tipo = "")
        {
            Form1 formPai = this.ParentForm as Form1;

            if (formPai != null)
            {
                formPai.ChamarMineTela(tela, nivelAcesso: tipo);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChamarSubTela(new CadFuncionario());
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ChamarSubTela(new CadFuncionario(id));
        }
    }
}
